package com.example.askaimod.mixin;

import com.example.askaimod.api.AiApiClient;
import com.example.askaimod.api.ChatMessage;
import com.example.askaimod.api.SystemPromptBuilder;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_463;
import net.minecraft.class_6379;

@Mixin(class_463.class)
public abstract class CommandBlockScreenMixin {
    @Shadow
    @Final
    protected class_342 commandEdit;

    @Shadow
    protected int width;

    @Shadow
    protected int height;

    @Shadow
    protected abstract <T extends class_364 & class_4068 & class_6379> T addRenderableWidget(T widget);

    @Unique
    private class_4185 askAiButton;

    @Inject(method = "addExtraControls", at = @At("TAIL"))
    private void addAiButton(CallbackInfo ci) {
        askAiButton = class_4185.method_46430(class_2561.method_43470("AI"), btn -> onAiButtonClick())
                .method_46434(this.width / 2 + 100, this.height / 4 + 120, 40, 20)
                .method_46431();
        addRenderableWidget(askAiButton);
    }

    @Unique
    private void onAiButtonClick() {
        askAiButton.field_22763 = false;
        askAiButton.method_25355(class_2561.method_43470("..."));

        List<ChatMessage> messages = List.of(
                new ChatMessage("system", SystemPromptBuilder.build()),
                new ChatMessage("user", "Help me with this command block. Current command:\n"
                        + commandEdit.method_1882()
                        + "\n\nSuggest improvements or explain what this command does.")
        );

        AiApiClient.sendMessage(messages).thenAcceptAsync(response -> {
            askAiButton.field_22763 = true;
            askAiButton.method_25355(class_2561.method_43470("AI"));

            String extractedCommand = extractCommand(response);
            if (extractedCommand != null) {
                commandEdit.method_1852(extractedCommand);
                class_310.method_1551().field_1724.method_7353(
                        class_2561.method_43470("§7[Ask AI] Command updated. Review before applying."), false);
            }
        }, class_310.method_1551());
    }

    @Unique
    private String extractCommand(String response) {
        Pattern codeBlockPattern = Pattern.compile("```(?:\\w+)?\\n(.*?)```", Pattern.DOTALL);
        Matcher matcher = codeBlockPattern.matcher(response);
        if (matcher.find()) {
            return matcher.group(1).strip();
        }

        String[] lines = response.split("\n");
        for (String line : lines) {
            String trimmed = line.strip();
            if (trimmed.startsWith("/")) {
                return trimmed;
            }
        }

        return null;
    }
}
