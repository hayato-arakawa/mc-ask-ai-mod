package com.example.askaimod.screen;

import com.example.askaimod.api.AiApiClient;
import com.example.askaimod.api.ChatMessage;
import com.example.askaimod.api.SystemPromptBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5250;

public class AiChatScreen extends class_437 {
    private static final int PADDING = 10;
    private static final int INPUT_HEIGHT = 20;
    private static final int SEND_BUTTON_WIDTH = 50;

    private class_342 inputField;
    private class_4185 sendButton;

    private final List<class_2561> responseLines = new ArrayList<>();
    private int scrollOffset = 0;

    private boolean isLoading = false;

    public AiChatScreen() {
        super(class_2561.method_43470("AI Chat"));
    }

    @Override
    protected void method_25426() {
        int inputY = this.field_22790 - INPUT_HEIGHT - PADDING;
        int inputWidth = this.field_22789 - PADDING * 2 - SEND_BUTTON_WIDTH - 5;

        inputField = new class_342(this.field_22793, PADDING, inputY, inputWidth, INPUT_HEIGHT,
                class_2561.method_43470("Ask AI..."));
        inputField.method_1880(256);
        method_37063(inputField);

        sendButton = class_4185.method_46430(class_2561.method_43470("Send"), btn -> sendMessage())
                .method_46434(this.field_22789 - PADDING - SEND_BUTTON_WIDTH, inputY, SEND_BUTTON_WIDTH, INPUT_HEIGHT)
                .method_46431();
        method_37063(sendButton);

        method_48265(inputField);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        super.method_25394(graphics, mouseX, mouseY, delta);

        int contentTop = PADDING;
        int contentBottom = this.field_22790 - INPUT_HEIGHT - PADDING * 2 - 5;

        graphics.method_25294(PADDING, contentTop, this.field_22789 - PADDING, contentBottom, 0x44000000);

        int y = contentTop + PADDING - scrollOffset;
        for (class_2561 line : responseLines) {
            if (y + 10 > contentTop && y - 10 < contentBottom) {
                graphics.method_51439(this.field_22793, line, PADDING + 5, y, 0xFFFFFF, false);
            }
            y += this.field_22793.field_2000 + 2;
        }

        if (isLoading) {
            graphics.method_51439(this.field_22793, class_2561.method_43470("Thinking..."), PADDING + 5,
                    contentTop + PADDING - scrollOffset + responseLines.size() * (this.field_22793.field_2000 + 2),
                    0x888888, false);
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        int totalHeight = responseLines.size() * (this.field_22793.field_2000 + 2);
        int viewHeight = this.field_22790 - INPUT_HEIGHT - PADDING * 2 - 5 - PADDING * 2;
        int maxScroll = Math.max(0, totalHeight - viewHeight);

        scrollOffset = (int) Math.clamp(scrollOffset - scrollY * 10, 0, maxScroll);
        return true;
    }

    @Override
    public boolean method_25404(net.minecraft.class_11908 event) {
        if (event.comp_4795() == 257 || event.comp_4795() == 335) {
            sendMessage();
            return true;
        }
        return super.method_25404(event);
    }

    private void sendMessage() {
        String text = inputField.method_1882().trim();
        if (text.isEmpty() || isLoading) return;

        responseLines.add(class_2561.method_43470("> " + text)
                .method_10862(class_2583.field_24360.method_36139(0x55FF55)));

        inputField.method_1852("");
        isLoading = true;

        List<ChatMessage> messages = new ArrayList<>();
        messages.add(new ChatMessage("system", SystemPromptBuilder.build()));
        messages.add(new ChatMessage("user", text));

        AiApiClient.sendMessage(messages).thenAcceptAsync(response -> {
            isLoading = false;
            renderClickableResponse(response);
        }, class_310.method_1551());
    }

    private void renderClickableResponse(String response) {
        responseLines.add(class_2561.method_43470(""));

        Pattern codeBlockPattern = Pattern.compile("```(?:\\w+)?\\n(.*?)```", Pattern.DOTALL);
        Matcher matcher = codeBlockPattern.matcher(response);
        int lastEnd = 0;

        while (matcher.find()) {
            if (matcher.start() > lastEnd) {
                String textBefore = response.substring(lastEnd, matcher.start());
                responseLines.add(class_2561.method_43470(textBefore));
            }

            String code = matcher.group(1).strip();
            String command = code.startsWith("/") ? code : "/" + code;
            class_5250 codeComponent = class_2561.method_43470(code)
                    .method_10862(class_2583.field_24360
                            .method_36139(0xAAAAAA)
                            .method_10958(new class_2558.class_10610(command))
                            .method_10949(new class_2568.class_10613(
                                    class_2561.method_43470("Click to insert into chat"))));
            responseLines.add(codeComponent);

            lastEnd = matcher.end();
        }

        if (lastEnd < response.length()) {
            String remaining = response.substring(lastEnd);
            String[] lines = remaining.split("\n");
            for (String line : lines) {
                String trimmed = line.strip();
                if (trimmed.startsWith("/")) {
                    class_5250 cmdComponent = class_2561.method_43470(trimmed)
                            .method_10862(class_2583.field_24360
                                    .method_36139(0xAAAAAA)
                                    .method_10958(new class_2558.class_10610(trimmed))
                                    .method_10949(new class_2568.class_10613(
                                            class_2561.method_43470("Click to insert into chat"))));
                    responseLines.add(cmdComponent);
                } else {
                    responseLines.add(class_2561.method_43470(trimmed));
                }
            }
        }

        int totalHeight = responseLines.size() * (this.field_22793.field_2000 + 2);
        int viewHeight = this.field_22790 - INPUT_HEIGHT - PADDING * 2 - 5 - PADDING * 2;
        scrollOffset = Math.max(0, totalHeight - viewHeight);
    }
}
