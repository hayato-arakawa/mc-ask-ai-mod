package com.example.askaimod.api;

import net.minecraft.class_12099;
import net.minecraft.class_1934;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class SystemPromptBuilder {
    public static String build() {
        class_310 client = class_310.method_1551();
        StringBuilder sb = new StringBuilder();

        sb.append("You are a Minecraft command assistant.\n");
        sb.append("Current context:\n");
        sb.append("- Version: 1.21.11 (Java Edition)\n");

        if (client.field_1761 != null) {
            class_1934 gameType = client.field_1761.method_2920();
            sb.append("- Gamemode: ").append(gameType != null ? gameType.method_8381() : "unknown").append("\n");
        }

        boolean isSingleplayer = client.method_1542();
        sb.append("- World type: ").append(isSingleplayer ? "singleplayer" : "multiplayer").append("\n");

        class_746 player = client.field_1724;
        if (player != null) {
            boolean isOperator = isSingleplayer
                    || player.method_75004().hasPermission(class_12099.field_63211);
            sb.append("- Operator: ").append(isOperator).append("\n");
        }

        sb.append("\nWhen providing commands, always wrap them in a code block starting with /.\n");
        sb.append("Explain what each command does briefly.\n");

        return sb.toString();
    }
}
