package com.example.askaimod.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            AskAiModConfig config = ConfigManager.getConfig();

            ConfigBuilder builder = ConfigBuilder.create()
                    .setParentScreen(parent)
                    .setTitle(class_2561.method_43470("Ask AI Mod Config"));

            ConfigEntryBuilder entryBuilder = builder.entryBuilder();

            ConfigCategory general = builder.getOrCreateCategory(class_2561.method_43470("General"));

            general.addEntry(entryBuilder.startStrField(
                    class_2561.method_43470("API Endpoint"),
                    config.getEndpoint()
            ).setDefaultValue("https://api.openai.com/v1")
                    .setSaveConsumer(config::setEndpoint)
                    .build());

            general.addEntry(entryBuilder.startStrField(
                    class_2561.method_43470("API Key"),
                    config.getApiKey()
            ).setDefaultValue("")
                    .setSaveConsumer(config::setApiKey)
                    .build());

            general.addEntry(entryBuilder.startStrField(
                    class_2561.method_43470("Model"),
                    config.getModel()
            ).setDefaultValue("gpt-4o-mini")
                    .setSaveConsumer(config::setModel)
                    .build());

            general.addEntry(entryBuilder.startDoubleField(
                    class_2561.method_43470("Temperature"),
                    config.getTemperature()
            ).setDefaultValue(0.7)
                    .setMin(0.0)
                    .setMax(2.0)
                    .setSaveConsumer(config::setTemperature)
                    .build());

            builder.setSavingRunnable(() -> ConfigManager.save(config));

            return builder.build();
        };
    }
}
